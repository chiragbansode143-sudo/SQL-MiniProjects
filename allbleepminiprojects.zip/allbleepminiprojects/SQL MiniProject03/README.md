 SQL Mini Project 03

## Data Cleaning & Transformation

### Objective

The objective of this project is to work with inconsistent and incomplete data and use SQL to clean and transform it.

### Dataset Used

**ClassicModels Database**

### Data Cleaning Areas

#### Missing Values

* Identify missing information.
* Handle NULL values appropriately.

#### Name Cleaning

* Identify inconsistent customer name information.
* Standardize name values.

#### Email Cleaning

* Identify and clean email-related data.

#### Phone Number Cleaning

* Identify inconsistent phone number formats.
* Remove unnecessary characters.
* Produce cleaner phone values.

#### Duplicate Detection

* Identify duplicate or repeated records.

#### Order Analysis

* Analyse order information.
* Identify relevant status conditions.

#### Product Transformation

* Extract useful information from existing product fields.

#### Data Inconsistency

* Identify records where available information does not logically match expected conditions.

#### Standardisation

* Standardize inconsistent values using SQL.

### SQL Concepts Used

* NULL Handling
* Data Cleaning
* Data Transformation
* String Manipulation
* Duplicate Detection
* UPDATE
* Conditional Logic
* Data Standardisation
* CASE
* COALESCE
* TRIM
* REPLACE

### Project Outcome

This project provides practical experience in identifying data-quality problems and applying SQL techniques to clean, transform, standardize, and analyse data.

### Key Learning

Data should be understood before it is changed. SQL cleaning operations should be performed intentionally after identifying the underlying data issue.
