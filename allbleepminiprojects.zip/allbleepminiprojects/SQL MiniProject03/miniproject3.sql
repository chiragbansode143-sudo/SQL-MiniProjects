use classicmodels;
SELECT *
FROM customers
WHERE customerName IS NULL
   OR contactLastName IS NULL
   OR contactFirstName IS NULL
   OR phone IS NULL
   OR addressLine1 IS NULL
   OR city IS NULL
   OR country IS NULL;

SELECT customerNumber, customerName
FROM customers
WHERE contactLastName IS NULL
   OR contactFirstName IS NULL;

SELECT customerNumber, customerName, phone
FROM customers
WHERE phone IS NULL;

SELECT customerNumber, customerName
FROM customers
WHERE customerName = '';

SELECT customerNumber, customerName
FROM customers
WHERE TRIM(customerName) <> customerName;

SELECT customerNumber, customerName,
       UPPER(customerName) AS standardized_customer_name
FROM customers;

SELECT customerNumber, contactFirstName, contactLastName,
       CONCAT(
           UPPER(LEFT(contactFirstName, 1)),
           LOWER(SUBSTRING(contactFirstName, 2))
       ) AS standardized_first_name,
       CONCAT(
           UPPER(LEFT(contactLastName, 1)),
           LOWER(SUBSTRING(contactLastName, 2))
       ) AS standardized_last_name
FROM customers;

SELECT customerNumber, customerName, phone
FROM customers
WHERE phone LIKE '%-%'
   OR phone LIKE '%(%'
   OR phone LIKE '%)%';

SELECT customerNumber, customerName, phone,
       REPLACE(
           REPLACE(
               REPLACE(
                   REPLACE(phone, '-', ''),
               '(', ''),
           ')', ''),
       ' ', '') AS cleaned_phone
FROM customers;

SELECT customerNumber, customerName, phone,
       REGEXP_REPLACE(phone, '[^0-9+]', '') AS cleaned_phone
FROM customers;

SELECT customerNumber, customerName
FROM customers
WHERE customerName LIKE '%  %';

SELECT customerNumber, customerName,
       TRIM(customerName) AS cleaned_customer_name
FROM customers;

SELECT customerNumber, customerName, salesRepEmployeeNumber
FROM customers
WHERE salesRepEmployeeNumber IS NULL;

SELECT customerNumber, customerName, creditLimit
FROM customers
WHERE creditLimit IS NULL;

SELECT productCode, productName, productLine
FROM products
WHERE productLine IS NULL;

SELECT productCode, productName, quantityInStock
FROM products
WHERE quantityInStock IS NULL;

SELECT productCode, productName, buyPrice, MSRP
FROM products
WHERE buyPrice IS NULL
   OR MSRP IS NULL;

SELECT productCode, productName, buyPrice, MSRP
FROM products
WHERE buyPrice <= 0
   OR MSRP <= 0;

SELECT productCode, productName, buyPrice, MSRP
FROM products
WHERE buyPrice > MSRP;

SELECT productCode, productName, quantityInStock
FROM products
WHERE quantityInStock < 0;

SELECT productCode, productName,
       CASE
           WHEN quantityInStock = 0 THEN 'Out of Stock'
           WHEN quantityInStock < 20 THEN 'Low Stock'
           WHEN quantityInStock < 50 THEN 'Medium Stock'
           ELSE 'High Stock'
       END AS stock_status
FROM products;

SELECT productCode, productName, buyPrice,
       CASE
           WHEN buyPrice < 50 THEN 'Low Price'
           WHEN buyPrice <= 100 THEN 'Medium Price'
           ELSE 'High Price'
       END AS price_category
FROM products;

SELECT productLine,
       COUNT(*) AS product_count
FROM products
GROUP BY productLine;

SELECT productLine,
       MIN(buyPrice) AS minimum_price,
       MAX(buyPrice) AS maximum_price,
       AVG(buyPrice) AS average_price
FROM products
GROUP BY productLine;

SELECT orderNumber, orderDate, requiredDate, shippedDate, status
FROM orders
WHERE shippedDate IS NULL;

SELECT orderNumber, orderDate, requiredDate, shippedDate, status
FROM orders
WHERE shippedDate IS NOT NULL
  AND shippedDate > requiredDate;

SELECT orderNumber, orderDate, requiredDate, shippedDate, status
FROM orders
WHERE requiredDate < orderDate;

SELECT orderNumber, orderDate, status
FROM orders
WHERE status IS NULL
   OR TRIM(status) = '';

SELECT orderNumber,
       status,
       CASE
           WHEN status = 'Shipped' THEN 'Completed'
           WHEN status = 'Cancelled' THEN 'Cancelled'
           WHEN status = 'Disputed' THEN 'Under Review'
           WHEN status = 'In Process' THEN 'Processing'
           WHEN status = 'Resolved' THEN 'Completed'
           ELSE 'Other'
       END AS standardized_status
FROM orders;

SELECT customerNumber, COUNT(*) AS duplicate_count
FROM customers
GROUP BY customerNumber
HAVING COUNT(*) > 1;

SELECT customerName, COUNT(*) AS duplicate_count
FROM customers
GROUP BY customerName
HAVING COUNT(*) > 1;

SELECT contactFirstName, contactLastName, COUNT(*) AS duplicate_count
FROM customers
GROUP BY contactFirstName, contactLastName
HAVING COUNT(*) > 1;

SELECT phone, COUNT(*) AS duplicate_count
FROM customers
GROUP BY phone
HAVING COUNT(*) > 1;

SELECT email
FROM customers
WHERE email IS NULL;

SELECT customerNumber, customerName
FROM customers
WHERE customerName LIKE '%@%';

SELECT customerNumber, customerName, phone
FROM customers
WHERE phone IS NOT NULL
  AND phone NOT REGEXP '^[0-9+() .-]+$';

SELECT productCode, productName, buyPrice, MSRP
FROM products
WHERE buyPrice > MSRP;

SELECT orderNumber, orderDate, shippedDate
FROM orders
WHERE shippedDate IS NOT NULL
  AND shippedDate < orderDate;

SELECT orderNumber, orderDate, requiredDate, shippedDate,
       DATEDIFF(shippedDate, orderDate) AS shipping_days
FROM orders
WHERE shippedDate IS NOT NULL;

SELECT orderNumber, orderDate, requiredDate, shippedDate,
       CASE
           WHEN shippedDate IS NULL THEN 'Not Shipped'
           WHEN shippedDate <= requiredDate THEN 'On Time'
           ELSE 'Late'
       END AS delivery_status
FROM orders;

SELECT productCode, productName,
       productDescription,
       SUBSTRING_INDEX(productDescription, ' ', 1) AS first_word
FROM products;

SELECT productCode, productName,
       LENGTH(productDescription) AS description_length
FROM products;

SELECT productCode, productName,
       UPPER(productLine) AS standardized_product_line
FROM products;

SELECT productLine, COUNT(*) AS product_count
FROM products
GROUP BY TRIM(productLine);

SELECT customerNumber, customerName, country,
       UPPER(TRIM(country)) AS standardized_country
FROM customers;

SELECT customerNumber, customerName, city,
       UPPER(TRIM(city)) AS standardized_city
FROM customers;

SELECT customerNumber, customerName,
       CASE
           WHEN creditLimit IS NULL THEN 0
           ELSE creditLimit
       END AS cleaned_credit_limit
FROM customers;

SELECT productCode, productName,
       CASE
           WHEN quantityInStock IS NULL THEN 0
           ELSE quantityInStock
       END AS cleaned_stock
FROM products;

SELECT orderNumber, status,
       COALESCE(status, 'Unknown') AS cleaned_status
FROM orders;

SELECT customerNumber, customerName,
       COALESCE(phone, 'Not Available') AS cleaned_phone
FROM customers;

SELECT customerNumber, customerName,
       COALESCE(salesRepEmployeeNumber, 0) AS sales_rep
FROM customers;

SELECT productCode, productName,
       REPLACE(productName, '  ', ' ') AS cleaned_product_name
FROM products;

SELECT customerNumber,
       TRIM(customerName) AS cleaned_customer_name,
       TRIM(city) AS cleaned_city,
       TRIM(country) AS cleaned_country
FROM customers;

SELECT orderNumber, status,
       CASE
           WHEN status IN ('Shipped', 'Resolved') THEN 'Completed'
           WHEN status IN ('In Process', 'Disputed') THEN 'Pending'
           WHEN status = 'Cancelled' THEN 'Cancelled'
           ELSE 'Unknown'
       END AS order_category
FROM orders;