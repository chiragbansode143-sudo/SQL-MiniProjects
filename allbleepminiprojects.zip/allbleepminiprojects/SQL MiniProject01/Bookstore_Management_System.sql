DROP DATABASE IF EXISTS BookNest;

CREATE DATABASE BookNest;

USE BookNest;

CREATE TABLE books(
BookId INT NOT NULL PRIMARY KEY,
BookTitle VARCHAR(50) NOT NULL,
Author VARCHAR(30) NOT NULL,
Category VARCHAR(25) NOT NULL,
Price DECIMAL(10,2) NOT NULL,
Stock INT NOT NULL
);

INSERT INTO books(BookId, BookTitle, Author, Category, Price, Stock)
VALUES
(1,'The Alchemist','Paulo Coelho','Fiction',399.00,25),
(2,'Atomic Habits','James Clear','Self Help',550.00,18),
(3,'Wings of Fire','A.P.J. Abdul Kalam','Biography',350.00,12),
(4,'Rich Dad Poor Dad','Robert Kiyosaki','Finance',499.00,7),
(5,'Ikigai','Hector Garcia','Lifestyle',299.00,30);

SELECT * FROM books;

ALTER TABLE books
ADD Publisher VARCHAR(40);

SELECT * FROM books;

ALTER TABLE books
ADD SupplierContact VARCHAR(15);

SELECT * FROM books;

ALTER TABLE books
DROP COLUMN Publisher;

SELECT * FROM books;

ALTER TABLE books
RENAME COLUMN SupplierContact TO SupplierPhone;

SELECT * FROM books;

ALTER TABLE books
ADD BookLocation VARCHAR(20);

ALTER TABLE books
RENAME TO book_inventory;

SELECT * FROM book_inventory;

ALTER TABLE book_inventory
MODIFY COLUMN SupplierPhone VARCHAR(20);

SELECT * FROM book_inventory;

SET SQL_SAFE_UPDATES = 0;

UPDATE book_inventory
SET SupplierPhone = '+91-9876543210'
WHERE BookId = 1;

UPDATE book_inventory
SET SupplierPhone = '+91-9876543211'
WHERE BookId = 2;

UPDATE book_inventory
SET SupplierPhone = '+91-9876543212',
BookLocation = 'Shelf A'
WHERE BookId = 3;

UPDATE book_inventory
SET SupplierPhone = '+91-9876543213',
BookLocation = 'Shelf B'
WHERE BookId = 4;

UPDATE book_inventory
SET SupplierPhone = '+91-9876543214',
BookLocation = 'Shelf C'
WHERE BookId = 5;

SELECT * FROM book_inventory;

DELETE FROM book_inventory
WHERE BookId = 5;

SELECT * FROM book_inventory;

INSERT INTO book_inventory
(BookId, BookTitle, Author, Category, Price, Stock, SupplierPhone, BookLocation)
VALUES
(5,'Ikigai','Hector Garcia','Lifestyle',299.00,30,'+91-9876543214','Shelf C');

SELECT * FROM book_inventory;

SELECT BookTitle, Price,
IF(Price >= 400,'Expensive','Affordable') AS PriceStatus
FROM book_inventory;

SELECT BookTitle, Stock,
IF(Stock <= 10,'Low Stock','Available') AS StockStatus
FROM book_inventory;

SELECT BookTitle, Stock,
CASE
    WHEN Stock = 0 THEN 'Out of Stock'
    WHEN Stock <= 10 THEN 'Low Stock'
    WHEN Stock <= 20 THEN 'Medium Stock'
    ELSE 'High Stock'
END AS StockCategory
FROM book_inventory;

SELECT BookTitle, Price,
CASE
    WHEN Price < 300 THEN 'Budget'
    WHEN Price BETWEEN 300 AND 500 THEN 'Regular'
    ELSE 'Premium'
END AS PriceCategory
FROM book_inventory;

SELECT BookTitle, Category,
CASE
    WHEN Category = 'Fiction' THEN 'Entertainment'
    WHEN Category = 'Self Help' THEN 'Personal Development'
    WHEN Category = 'Biography' THEN 'Inspirational'
    WHEN Category = 'Finance' THEN 'Money Management'
    ELSE 'General Reading'
END AS CategoryGroup
FROM book_inventory;

SELECT BookId, BookTitle, SupplierPhone
FROM book_inventory;

SELECT * FROM book_inventory;

