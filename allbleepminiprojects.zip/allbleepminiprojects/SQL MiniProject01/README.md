SQL Mini Project 01

## SQL Fundamentals — Bookstore Management System

### Objective

The objective of this project is to demonstrate fundamental SQL operations for creating and managing a bookstore database, modifying table structures, managing records, updating information, deleting records, and creating categories using conditional logic.

### Dataset Used

**BookNest Bookstore Database**

### Analysis Areas

#### Database Creation

Create and use a dedicated database for managing bookstore information.

#### Table Creation

Create a book inventory table containing book details such as title, author, category, price, and stock.

#### Record Management

Insert book records and retrieve inventory information using SQL queries.

#### Table Modification

Modify the table structure by adding, removing, renaming, and modifying columns.

#### Record Updates

Update supplier contact details and book storage locations for existing records.

#### Record Deletion

Delete a selected book record from the inventory and restore the record when required.

#### Conditional Logic

Use conditional expressions to classify books based on price and stock availability.

#### Category Creation

Use CASE statements to create stock, price, and book-category classifications.

### SQL Concepts Used

* CREATE DATABASE
* CREATE TABLE
* INSERT INTO
* SELECT
* ALTER TABLE
* ADD COLUMN
* DROP COLUMN
* RENAME COLUMN
* RENAME TABLE
* MODIFY COLUMN
* UPDATE
* DELETE
* IF()
* CASE
* WHERE
* Primary Key
* Conditional Logic
* Data Categorization

### Project Outcome

This project provides practical experience with SQL database creation, table management, record manipulation, table structure modification, conditional logic, and data categorization using a bookstore inventory dataset.

### Key Learning

This project demonstrates how SQL can be used to create and manage a database, modify table structures, maintain records, and apply conditional logic to organize and categorize data for practical database management.
