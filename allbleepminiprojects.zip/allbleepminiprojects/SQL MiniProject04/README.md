# SQL Mini Project 04

## Relational Analysis with JOINs

### Objective

The objective of this project is to learn how to connect information stored across multiple tables and use the relationships between tables to answer business questions.

### Dataset Used

**ClassicModels Database**

### Analysis Areas

#### Customer & Payment Analysis

Connect customer information with payment information to analyse customer payment activity.

#### Employee & Office Analysis

Connect employees with their respective offices and analyse employee information across offices.

#### Order & Product Analysis

Connect order information with product information to analyse products and orders.

#### Office Analysis

Analyse employees across different offices.

#### Sales Representative Analysis

Connect customers with their assigned sales representatives.

#### Employee Hierarchy

Use a SELF JOIN to analyse employee-manager relationships.

#### Missing Relationships

Identify:

* Customers without orders
* Products that have never been sold
* Records without matching relationships

### SQL Concepts Used

* INNER JOIN
* LEFT JOIN
* RIGHT JOIN
* SELF JOIN
* CROSS JOIN
* Multiple-Table JOINs
* Aggregation with JOINs
* Filtering Joined Data

### Project Outcome

This project provides practical experience in combining data from multiple related tables and analysing relationships within the ClassicModels database.

### Key Learning

Before writing a JOIN query, it is important to identify what information is required, which tables contain that information, and how those tables are related.
