use classicmodels;
SELECT customers.customerNumber, customers.customerName, payments.paymentDate, payments.amount
FROM customers
INNER JOIN payments
ON customers.customerNumber = payments.customerNumber;

SELECT customers.customerNumber, customers.customerName, payments.amount
FROM customers
INNER JOIN payments
ON customers.customerNumber = payments.customerNumber;

SELECT customers.customerNumber, customers.customerName, SUM(payments.amount) AS total_payment
FROM customers
INNER JOIN payments
ON customers.customerNumber = payments.customerNumber
GROUP BY customers.customerNumber, customers.customerName
ORDER BY total_payment DESC;

SELECT customers.customerNumber, customers.customerName, AVG(payments.amount) AS average_payment
FROM customers
INNER JOIN payments
ON customers.customerNumber = payments.customerNumber
GROUP BY customers.customerNumber, customers.customerName;

SELECT employees.employeeNumber, employees.firstName, employees.lastName,
       offices.officeCode, offices.city, offices.country
FROM employees
INNER JOIN offices
ON employees.officeCode = offices.officeCode;

SELECT employees.employeeNumber, employees.firstName, employees.lastName,
       offices.city
FROM employees
INNER JOIN offices
ON employees.officeCode = offices.officeCode
WHERE offices.country = 'USA';

SELECT orders.orderNumber, orders.orderDate, orders.status,
       customers.customerName
FROM orders
INNER JOIN customers
ON orders.customerNumber = customers.customerNumber;

SELECT orders.orderNumber, customers.customerName,
       orderdetails.productCode, orderdetails.quantityOrdered
FROM orders
INNER JOIN customers
ON orders.customerNumber = customers.customerNumber
INNER JOIN orderdetails
ON orders.orderNumber = orderdetails.orderNumber;

SELECT orderdetails.orderNumber, orderdetails.productCode,
       products.productName, orderdetails.quantityOrdered,
       orderdetails.priceEach
FROM orderdetails
INNER JOIN products
ON orderdetails.productCode = products.productCode;

SELECT orders.orderNumber, customers.customerName,
       products.productName, orderdetails.quantityOrdered,
       orderdetails.priceEach
FROM orders
INNER JOIN customers
ON orders.customerNumber = customers.customerNumber
INNER JOIN orderdetails
ON orders.orderNumber = orderdetails.orderNumber
INNER JOIN products
ON orderdetails.productCode = products.productCode;

SELECT employees.employeeNumber,
       employees.firstName,
       employees.lastName,
       employees.officeCode,
       offices.city
FROM employees
LEFT JOIN offices
ON employees.officeCode = offices.officeCode;

SELECT customers.customerNumber, customers.customerName,
       orders.orderNumber, orders.orderDate
FROM customers
LEFT JOIN orders
ON customers.customerNumber = orders.customerNumber;

SELECT customers.customerNumber, customers.customerName
FROM customers
LEFT JOIN orders
ON customers.customerNumber = orders.customerNumber
WHERE orders.orderNumber IS NULL;

SELECT products.productCode, products.productName
FROM products
LEFT JOIN orderdetails
ON products.productCode = orderdetails.productCode
WHERE orderdetails.productCode IS NULL;

SELECT employees.employeeNumber,
       employees.firstName,
       employees.lastName,
       employees.reportsTo
FROM employees
WHERE reportsTo IS NOT NULL;

SELECT employee.employeeNumber,
       employee.firstName AS employee_first_name,
       employee.lastName AS employee_last_name,
       manager.firstName AS manager_first_name,
       manager.lastName AS manager_last_name
FROM employees AS employee
LEFT JOIN employees AS manager
ON employee.reportsTo = manager.employeeNumber;

SELECT employee.employeeNumber,
       employee.firstName,
       employee.lastName,
       manager.firstName AS manager_first_name,
       manager.lastName AS manager_last_name
FROM employees AS employee
INNER JOIN employees AS manager
ON employee.reportsTo = manager.employeeNumber;

SELECT customers.customerNumber,
       customers.customerName,
       employees.firstName,
       employees.lastName
FROM customers
INNER JOIN employees
ON customers.salesRepEmployeeNumber = employees.employeeNumber;

SELECT customers.customerNumber,
       customers.customerName,
       employees.firstName,
       employees.lastName
FROM customers
LEFT JOIN employees
ON customers.salesRepEmployeeNumber = employees.employeeNumber;

SELECT offices.officeCode,
       offices.city,
       COUNT(employees.employeeNumber) AS employee_count
FROM offices
LEFT JOIN employees
ON offices.officeCode = employees.officeCode
GROUP BY offices.officeCode, offices.city;

SELECT employees.employeeNumber,
       employees.firstName,
       employees.lastName,
       COUNT(customers.customerNumber) AS customer_count
FROM employees
LEFT JOIN customers
ON employees.employeeNumber = customers.salesRepEmployeeNumber
GROUP BY employees.employeeNumber, employees.firstName, employees.lastName
ORDER BY customer_count DESC;

SELECT customers.customerNumber,
       customers.customerName,
       SUM(payments.amount) AS total_payment
FROM customers
INNER JOIN payments
ON customers.customerNumber = payments.customerNumber
GROUP BY customers.customerNumber, customers.customerName
ORDER BY total_payment DESC;

SELECT customers.customerNumber,
       customers.customerName,
       COUNT(payments.customerNumber) AS payment_count
FROM customers
LEFT JOIN payments
ON customers.customerNumber = payments.customerNumber
GROUP BY customers.customerNumber, customers.customerName
ORDER BY payment_count DESC;

SELECT products.productCode,
       products.productName,
       SUM(orderdetails.quantityOrdered) AS total_quantity_sold
FROM products
INNER JOIN orderdetails
ON products.productCode = orderdetails.productCode
GROUP BY products.productCode, products.productName
ORDER BY total_quantity_sold DESC;

SELECT products.productCode,
       products.productName,
       SUM(orderdetails.quantityOrdered * orderdetails.priceEach) AS total_sales
FROM products
INNER JOIN orderdetails
ON products.productCode = orderdetails.productCode
GROUP BY products.productCode, products.productName
ORDER BY total_sales DESC;

SELECT productlines.productLine,
       COUNT(products.productCode) AS product_count
FROM productlines
LEFT JOIN products
ON productlines.productLine = products.productLine
GROUP BY productlines.productLine;

SELECT customers.customerNumber,
       customers.customerName,
       COUNT(orders.orderNumber) AS order_count
FROM customers
LEFT JOIN orders
ON customers.customerNumber = orders.customerNumber
GROUP BY customers.customerNumber, customers.customerName
HAVING COUNT(orders.orderNumber) > 0;

SELECT customers.customerNumber,
       customers.customerName,
       COUNT(orders.orderNumber) AS order_count
FROM customers
LEFT JOIN orders
ON customers.customerNumber = orders.customerNumber
GROUP BY customers.customerNumber, customers.customerName
HAVING COUNT(orders.orderNumber) = 0;

SELECT products.productCode,
       products.productName,
       COUNT(orderdetails.orderNumber) AS order_count
FROM products
LEFT JOIN orderdetails
ON products.productCode = orderdetails.productCode
GROUP BY products.productCode, products.productName
HAVING COUNT(orderdetails.orderNumber) = 0;

SELECT customers.customerNumber,
       customers.customerName,
       employees.firstName,
       employees.lastName,
       offices.city
FROM customers
INNER JOIN employees
ON customers.salesRepEmployeeNumber = employees.employeeNumber
INNER JOIN offices
ON employees.officeCode = offices.officeCode;

SELECT orders.orderNumber,
       customers.customerName,
       products.productName,
       orderdetails.quantityOrdered,
       orderdetails.priceEach,
       (orderdetails.quantityOrdered * orderdetails.priceEach) AS line_total
FROM orders
INNER JOIN customers
ON orders.customerNumber = customers.customerNumber
INNER JOIN orderdetails
ON orders.orderNumber = orderdetails.orderNumber
INNER JOIN products
ON orderdetails.productCode = products.productCode;

SELECT customers.customerNumber,
       customers.customerName,
       COUNT(DISTINCT orders.orderNumber) AS order_count,
       SUM(orderdetails.quantityOrdered * orderdetails.priceEach) AS total_sales
FROM customers
INNER JOIN orders
ON customers.customerNumber = orders.customerNumber
INNER JOIN orderdetails
ON orders.orderNumber = orderdetails.orderNumber
GROUP BY customers.customerNumber, customers.customerName
ORDER BY total_sales DESC;

SELECT offices.officeCode,
       offices.city,
       COUNT(DISTINCT employees.employeeNumber) AS employee_count,
       COUNT(DISTINCT customers.customerNumber) AS customer_count
FROM offices
LEFT JOIN employees
ON offices.officeCode = employees.officeCode
LEFT JOIN customers
ON employees.employeeNumber = customers.salesRepEmployeeNumber
GROUP BY offices.officeCode, offices.city;