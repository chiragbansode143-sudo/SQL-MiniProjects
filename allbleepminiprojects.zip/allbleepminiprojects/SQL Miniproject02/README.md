 SQL Mini Project 02

 ClassicModels Query Challenge

 Objective

The objective of this project is to use SQL to explore the ClassicModels database and answer structured business questions.

 Dataset Used

**ClassicModels Database**

The database contains information related to customers, products, payments, orders, and other business operations.

 Areas Covered

Customer Analysis

* Customer locations
* Credit limits
* Customer searches
* Sales representatives
* Customer payments

 Product Analysis

* Product prices
* Product lines
* Stock levels
* Product searches
* Product sorting

 Payment Analysis

* Payment dates
* Payment counts
* Customer payment activity
* Total payments
* Average payments
* Minimum payments
* Maximum payments

 SQL Concepts Used

* SELECT
* WHERE
* ORDER BY
* GROUP BY
* HAVING
* LIKE
* IN
* LIMIT
* OFFSET
* Aggregate Functions
* Subqueries
* Filtering
* Sorting

 Project Outcome

This project provides practical experience in querying the ClassicModels database and extracting useful information through filtering, sorting, grouping, aggregation, and subqueries.

 Key Learning

The project focuses on understanding not only how to write SQL queries, but also why each query works and how SQL can be used to explore business data.
