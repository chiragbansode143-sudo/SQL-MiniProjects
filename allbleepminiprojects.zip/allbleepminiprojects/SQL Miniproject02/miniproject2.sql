use classicmodels;
USE classicmodels;

SELECT *
FROM customers;

SELECT customerName, city, country
FROM customers;

SELECT customerName, city, country
FROM customers
WHERE country = 'USA';

SELECT customerName, country
FROM customers
WHERE country IN ('USA', 'Canada', 'France');

SELECT customerName, creditLimit
FROM customers
WHERE creditLimit > 100000;

SELECT customerName, creditLimit
FROM customers
WHERE creditLimit BETWEEN 50000 AND 100000;

SELECT customerName
FROM customers
WHERE customerName LIKE 'A%';

SELECT customerName
FROM customers
WHERE customerName LIKE '%Auto%';

SELECT customerName, creditLimit
FROM customers
ORDER BY creditLimit DESC;

SELECT customerName, creditLimit
FROM customers
ORDER BY creditLimit DESC
LIMIT 5;

SELECT customerNumber, customerName
FROM customers
ORDER BY customerNumber
LIMIT 5 OFFSET 5;

SELECT COUNT(*) AS total_customers
FROM customers;

SELECT AVG(creditLimit) AS average_credit_limit
FROM customers;

SELECT MIN(creditLimit) AS minimum_credit_limit
FROM customers;

SELECT MAX(creditLimit) AS maximum_credit_limit
FROM customers;

SELECT country, COUNT(*) AS customer_count
FROM customers
GROUP BY country
ORDER BY customer_count DESC;

SELECT country, COUNT(*) AS customer_count
FROM customers
GROUP BY country
HAVING COUNT(*) > 5;

SELECT customerName, salesRepEmployeeNumber
FROM customers;

SELECT productCode, productName, buyPrice
FROM products;

SELECT productCode, productName, buyPrice
FROM products
WHERE buyPrice > 50;

SELECT productCode, productName, buyPrice
FROM products
WHERE buyPrice BETWEEN 50 AND 100;

SELECT productCode, productName, productLine
FROM products
WHERE productLine IN ('Classic Cars', 'Motorcycles');

SELECT productCode, productName
FROM products
WHERE productName LIKE '%Ford%';

SELECT productCode, productName, buyPrice
FROM products
ORDER BY buyPrice DESC;

SELECT productCode, productName, buyPrice
FROM products
ORDER BY buyPrice DESC
LIMIT 10;

SELECT productCode, productName, quantityInStock
FROM products
WHERE quantityInStock > 50;

SELECT productCode, productName, quantityInStock
FROM products
WHERE quantityInStock < 20;

SELECT COUNT(*) AS total_products
FROM products;

SELECT AVG(buyPrice) AS average_price
FROM products;

SELECT 
    MIN(buyPrice) AS minimum_price,
    MAX(buyPrice) AS maximum_price
FROM products;

SELECT productLine, COUNT(*) AS product_count
FROM products
GROUP BY productLine;

SELECT productLine, COUNT(*) AS product_count
FROM products
GROUP BY productLine
HAVING COUNT(*) > 10;

SELECT *
FROM payments;

SELECT customerNumber, paymentDate, amount
FROM payments
ORDER BY paymentDate;

SELECT customerNumber, paymentDate, amount
FROM payments
WHERE amount > 50000;

SELECT customerNumber, paymentDate, amount
FROM payments
WHERE YEAR(paymentDate) = 2004;

SELECT COUNT(*) AS total_payments
FROM payments;

SELECT SUM(amount) AS total_payment
FROM payments;

SELECT AVG(amount) AS average_payment
FROM payments;

SELECT 
    MIN(amount) AS minimum_payment,
    MAX(amount) AS maximum_payment
FROM payments;

SELECT customerNumber, COUNT(*) AS payment_count
FROM payments
GROUP BY customerNumber
ORDER BY payment_count DESC;

SELECT customerNumber, SUM(amount) AS total_payment
FROM payments
GROUP BY customerNumber
ORDER BY total_payment DESC;

SELECT customerNumber, AVG(amount) AS average_payment
FROM payments
GROUP BY customerNumber
ORDER BY average_payment DESC;

SELECT customerNumber, SUM(amount) AS total_payment
FROM payments
GROUP BY customerNumber
HAVING SUM(amount) > 100000;

SELECT customerNumber, paymentDate, amount
FROM payments
WHERE amount = (
    SELECT MAX(amount)
    FROM payments
);

SELECT productCode, productName, buyPrice
FROM products
WHERE buyPrice > (
    SELECT AVG(buyPrice)
    FROM products
);

SELECT customerNumber, customerName, creditLimit
FROM customers
WHERE creditLimit > (
    SELECT AVG(creditLimit)
    FROM customers
);

SELECT productCode, productName, buyPrice
FROM products
WHERE buyPrice = (
    SELECT MAX(buyPrice)
    FROM products
);

SELECT productCode, productName, buyPrice
FROM products
WHERE buyPrice = (
    SELECT MIN(buyPrice)
    FROM products
);

SELECT productCode, productName, buyPrice
FROM products
ORDER BY buyPrice DESC
LIMIT 1 OFFSET 1;