use classicmodels;
SELECT
    productCode,
    productName,
    productLine,
    buyPrice,
    ROW_NUMBER() OVER (
        PARTITION BY productLine
        ORDER BY buyPrice DESC
    ) AS row_number_rank
FROM products;

SELECT
    productCode,
    productName,
    productLine,
    buyPrice,
    RANK() OVER (
        PARTITION BY productLine
        ORDER BY buyPrice DESC
    ) AS product_rank
FROM products;

SELECT
    productCode,
    productName,
    productLine,
    buyPrice,
    DENSE_RANK() OVER (
        PARTITION BY productLine
        ORDER BY buyPrice DESC
    ) AS dense_product_rank
FROM products;

SELECT
    productCode,
    productName,
    productLine,
    buyPrice,
    ROW_NUMBER() OVER (
        ORDER BY buyPrice DESC
    ) AS overall_rank
FROM products;

SELECT
    productCode,
    productName,
    productLine,
    buyPrice,
    RANK() OVER (
        PARTITION BY productLine
        ORDER BY buyPrice DESC
    ) AS product_rank
FROM products;

SELECT *
FROM (
    SELECT
        productCode,
        productName,
        productLine,
        buyPrice,
        RANK() OVER (
            PARTITION BY productLine
            ORDER BY buyPrice DESC
        ) AS product_rank
    FROM products
) AS ranked_products
WHERE product_rank <= 3;

SELECT
    paymentDate,
    amount,
    SUM(amount) OVER (
        ORDER BY paymentDate
    ) AS running_total
FROM payments
ORDER BY paymentDate;

SELECT
    paymentDate,
    amount,
    SUM(amount) OVER (
        PARTITION BY customerNumber
        ORDER BY paymentDate
    ) AS customer_running_total
FROM payments
ORDER BY customerNumber, paymentDate;

SELECT
    customerNumber,
    paymentDate,
    amount,
    LAG(amount) OVER (
        PARTITION BY customerNumber
        ORDER BY paymentDate
    ) AS previous_payment
FROM payments;

SELECT
    customerNumber,
    paymentDate,
    amount,
    amount - LAG(amount) OVER (
        PARTITION BY customerNumber
        ORDER BY paymentDate
    ) AS payment_difference
FROM payments;

SELECT
    customerNumber,
    paymentDate,
    amount,
    LAG(amount) OVER (
        PARTITION BY customerNumber
        ORDER BY paymentDate
    ) AS previous_payment,
    CASE
        WHEN amount > LAG(amount) OVER (
            PARTITION BY customerNumber
            ORDER BY paymentDate
        ) THEN 'Increased'
        WHEN amount < LAG(amount) OVER (
            PARTITION BY customerNumber
            ORDER BY paymentDate
        ) THEN 'Decreased'
        ELSE 'No Change'
    END AS payment_change
FROM payments;

WITH monthly_payments AS (
    SELECT
        DATE_FORMAT(paymentDate, '%Y-%m') AS payment_month,
        SUM(amount) AS total_payment
    FROM payments
    GROUP BY DATE_FORMAT(paymentDate, '%Y-%m')
)
SELECT
    payment_month,
    total_payment,
    LAG(total_payment) OVER (
        ORDER BY payment_month
    ) AS previous_month_payment
FROM monthly_payments
ORDER BY payment_month;

WITH monthly_payments AS (
    SELECT
        DATE_FORMAT(paymentDate, '%Y-%m') AS payment_month,
        SUM(amount) AS total_payment
    FROM payments
    GROUP BY DATE_FORMAT(paymentDate, '%Y-%m')
)
SELECT
    payment_month,
    total_payment,
    LAG(total_payment) OVER (
        ORDER BY payment_month
    ) AS previous_month_payment,
    total_payment - LAG(total_payment) OVER (
        ORDER BY payment_month
    ) AS payment_growth
FROM monthly_payments
ORDER BY payment_month;

WITH monthly_payments AS (
    SELECT
        DATE_FORMAT(paymentDate, '%Y-%m') AS payment_month,
        SUM(amount) AS total_payment
    FROM payments
    GROUP BY DATE_FORMAT(paymentDate, '%Y-%m')
)
SELECT
    payment_month,
    total_payment,
    LAG(total_payment) OVER (
        ORDER BY payment_month
    ) AS previous_month_payment,
    ROUND(
        (
            total_payment - LAG(total_payment) OVER (
                ORDER BY payment_month
            )
        ) /
        LAG(total_payment) OVER (
            ORDER BY payment_month
        ) * 100,
        2
    ) AS growth_percentage
FROM monthly_payments
ORDER BY payment_month;

WITH monthly_payments AS (
    SELECT
        DATE_FORMAT(paymentDate, '%Y-%m') AS payment_month,
        SUM(amount) AS total_payment
    FROM payments
    GROUP BY DATE_FORMAT(paymentDate, '%Y-%m')
)
SELECT
    payment_month,
    total_payment,
    AVG(total_payment) OVER (
        ORDER BY payment_month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS three_month_moving_average
FROM monthly_payments
ORDER BY payment_month;

WITH monthly_sales AS (
    SELECT
        DATE_FORMAT(o.orderDate, '%Y-%m') AS sales_month,
        SUM(od.quantityOrdered * od.priceEach) AS total_sales
    FROM orders o
    INNER JOIN orderdetails od
        ON o.orderNumber = od.orderNumber
    GROUP BY DATE_FORMAT(o.orderDate, '%Y-%m')
)
SELECT
    sales_month,
    total_sales,
    SUM(total_sales) OVER (
        ORDER BY sales_month
    ) AS running_sales_total
FROM monthly_sales
ORDER BY sales_month;

WITH monthly_sales AS (
    SELECT
        DATE_FORMAT(o.orderDate, '%Y-%m') AS sales_month,
        SUM(od.quantityOrdered * od.priceEach) AS total_sales
    FROM orders o
    INNER JOIN orderdetails od
        ON o.orderNumber = od.orderNumber
    GROUP BY DATE_FORMAT(o.orderDate, '%Y-%m')
)
SELECT
    sales_month,
    total_sales,
    LAG(total_sales) OVER (
        ORDER BY sales_month
    ) AS previous_month_sales,
    total_sales - LAG(total_sales) OVER (
        ORDER BY sales_month
    ) AS sales_growth
FROM monthly_sales
ORDER BY sales_month;

WITH monthly_sales AS (
    SELECT
        DATE_FORMAT(o.orderDate, '%Y-%m') AS sales_month,
        SUM(od.quantityOrdered * od.priceEach) AS total_sales
    FROM orders o
    INNER JOIN orderdetails od
        ON o.orderNumber = od.orderNumber
    GROUP BY DATE_FORMAT(o.orderDate, '%Y-%m')
)
SELECT
    sales_month,
    total_sales,
    AVG(total_sales) OVER (
        ORDER BY sales_month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS three_month_moving_average
FROM monthly_sales
ORDER BY sales_month;

WITH product_sales AS (
    SELECT
        p.productCode,
        p.productName,
        p.productLine,
        SUM(od.quantityOrdered * od.priceEach) AS total_sales
    FROM products p
    INNER JOIN orderdetails od
        ON p.productCode = od.productCode
    GROUP BY p.productCode, p.productName, p.productLine
)
SELECT
    productCode,
    productName,
    productLine,
    total_sales,
    RANK() OVER (
        PARTITION BY productLine
        ORDER BY total_sales DESC
    ) AS sales_rank
FROM product_sales;

WITH product_sales AS (
    SELECT
        p.productCode,
        p.productName,
        p.productLine,
        SUM(od.quantityOrdered * od.priceEach) AS total_sales
    FROM products p
    INNER JOIN orderdetails od
        ON p.productCode = od.productCode
    GROUP BY p.productCode, p.productName, p.productLine
)
SELECT *
FROM (
    SELECT
        productCode,
        productName,
        productLine,
        total_sales,
        RANK() OVER (
            PARTITION BY productLine
            ORDER BY total_sales DESC
        ) AS sales_rank
    FROM product_sales
) AS ranked_products
WHERE sales_rank <= 3;