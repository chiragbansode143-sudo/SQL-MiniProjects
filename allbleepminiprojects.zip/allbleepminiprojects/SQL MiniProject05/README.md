# SQL Mini Project 05

## Advanced SQL — Window Functions

### Objective

The objective of this project is to use advanced SQL techniques for ranking, running-total, comparison, growth, and time-based analysis.

### Dataset Used

**ClassicModels Database**

### Analysis Areas

#### Product Ranking

Rank products within their respective product lines.

#### Running Totals

Calculate cumulative payment values using window functions.

#### Top Products

Identify the highest-ranked products within product lines.

#### Month-over-Month Analysis

Compare values between different months.

#### Growth Analysis

Calculate changes between different periods.

#### Moving Average

Calculate a three-month moving average.

### SQL Concepts Used

* Window Functions
* ROW_NUMBER()
* RANK()
* DENSE_RANK()
* PARTITION BY
* ORDER BY
* SUM() OVER()
* LAG()
* Running Totals
* Moving Averages
* CTEs

### Project Outcome

This project provides practical experience with advanced SQL analysis techniques, including ranking records, calculating running totals, comparing periods, measuring growth, and calculating moving averages.

### Key Learning

Window functions allow analytical calculations to be performed across related rows while retaining the individual rows in the result set.
